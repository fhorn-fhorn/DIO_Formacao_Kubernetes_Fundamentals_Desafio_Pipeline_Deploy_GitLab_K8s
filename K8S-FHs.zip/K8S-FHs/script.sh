#!/bin/bash

echo "Criando as imagens ...."

docker build -t fhorn/k8s-fhs:1.0 /.

echo "Realizando push das imagens ...."

docker push /k8s-fhs:1.0 /.

echo "Criando serviços no cluster kubernetes ...."

kubectl apply -f ./services.yml

echo "Criando deployments ...."

kubectl apply -f ./deployment.yml

echo "FIM"