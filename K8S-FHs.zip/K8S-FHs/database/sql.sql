CREATE TABLE mensagens {
    id int,
    nome varchar(50),
    email varchar(50),
    comentario varchar(100)
};